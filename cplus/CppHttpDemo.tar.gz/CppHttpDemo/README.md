# CppHttpDemo
light weight C++ httpserver and httpclient based on mongoose

## httpclient

```
g++ main.cpp http_client.cpp ../common/mongoose.c  -I ./  -std=c++11 -o httpclient
```

## httpserver

```
g++ main.cpp http_server.cpp ../common/mongoose.c  -I ./  -std=c++11 -o httpserver
```

