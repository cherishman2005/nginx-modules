#!/bash/bin

# Mac 查看端口占用
# sudo lsof -nP -iTCP |grep 8080

# 启动服务
php -S 0.0.0.0:8080