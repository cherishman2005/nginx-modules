struct RequiredField {
  1: required string name
}

struct OtherThing {
  1: required i16 value
}
