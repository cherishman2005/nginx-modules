## PHP Coding Standards

Please follow:
 * [Thrift General Coding Standards](/doc/coding_standards.md)
 * [PSR-2](http://www.php-fig.org/psr/psr-2/)
